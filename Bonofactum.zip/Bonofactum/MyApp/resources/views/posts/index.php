<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <title>Data Posts</title>
  </head>

  <body>

    <div class="container" style="margin-top: 80px">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              DATA POSTS
            </div>
            <div class="card-body">
              <a href="create" class="btn btn-md btn-success" style="margin-bottom: 10px">TAMBAH DATA</a>
              <table class="table table-bordered" id="myTable">
                <thead>
                  <tr>
                    <th scope="col">Contact Person</th>
                    <th scope="col">Email</th>
                    <th scope="col">Address Country</th>
                    <th scope="col">ZIP Code</th>
                    <th scope="col">Minimum Order</th>
                    <th scope="col">Acceptable Lead Time</th>
                    <th scope="col">Type</th>
                    <th scope="col">Material</th>
                    <th scope="col">Description</th>
                  </tr>
                </thead>
                <tbody>


                  <?php
                    foreach($posts as $post)
                    {
                  ?>
                  <tr>
                      <td><?php echo $post["contactPerson"];?></td>
                      <td><?php echo $post["email"];?></td>
                      <td><?php echo $post["addressCountry"];?></td>
                      <td><?php echo $post["zipCode"];?></td>
                      <td><?php echo $post["minimumOrder"];?></td>
                      <td><?php echo $post["acceptableLeadTime"];?></td>
                      <td><?php echo $post["type"];?></td>
                      <td><?php echo $post["material"];?></td>
                      <td><?php echo $post["desc"];?></td>
                  </tr>
                  <?php
                    }
                  ?>


                </tbody>
              </table>
            </div>
          </div>
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
      $(document).ready( function () {
          $('#myTable').DataTable();
      } );
    </script>
  </body>
</html>