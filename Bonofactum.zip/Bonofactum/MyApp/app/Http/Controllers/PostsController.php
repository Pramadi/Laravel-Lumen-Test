<?php

namespace App\Http\Controllers;

use App\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PostsController extends Controller
{
    public function index()
    {
        $posts = Post::all();
        return view('posts.index', ['posts' => $posts]);
    }

    public function create()
	{
	    return view('posts.create');
	}

    public function store(Request $request)
	{
	    $validator = Validator::make($request->all(), [
	        'contactPerson' => 'required',
	        'email' => 'required',
	        'addressCountry' => 'required',
	        'zipCode' => 'required',
	        'minimumOrder' => 'required',
	        'acceptableLeadTime' => 'required',
	        'type' => 'required',
	        'material' => 'required',
	        'desc' => 'required',
	    ]);

	    if ($validator->fails()) {

	        return response()->json([
	            'success' => false,
	            'message' => 'Semua Kolom Wajib Diisi!',
	            'data'   => $validator->errors()
	        ],401);

	    } else {

	        $post = Post::create([
	            'contactPerson' => $request->input('contactPerson'),
		        'email' => $request->input('email'),
		        'addressCountry' => $request->input('addressCountry'),
		        'zipCode' => $request->input('zipCode'),
		        'minimumOrder' => $request->input('minimumOrder'),
		        'acceptableLeadTime' => $request->input('acceptableLeadTime'),
		        'type' => $request->input('type'),
		        'material' => $request->input('material'),
		        'desc' => $request->input('desc'),
	        ]);

	        // if ($post) {
	        //     return response()->json([
	        //         'success' => true,
	        //         'message' => 'Post Berhasil Disimpan!',
	        //         'data' => $post
	        //     ], 201);
	        // } else {
	        //     return response()->json([
	        //         'success' => false,
	        //         'message' => 'Post Gagal Disimpan!',
	        //     ], 400);
	        // }

	        return redirect('posts');

	    }
	}

	// public function show($id)
	// {
	//    $post = Post::find($id);

	//    if ($post) {
	//        return response()->json([
	//            'success'   => true,
	//            'message'   => 'Detail Post!',
	//            'data'      => $post
	//        ], 200);
	//    } else {
	//        return response()->json([
	//            'success' => false,
	//            'message' => 'Post Tidak Ditemukan!',
	//        ], 404);
	//    }
	// }

	// public function update(Request $request, $id)
	// {
	//     $validator = Validator::make($request->all(), [
	//         'title'   => 'required',
	//         'content' => 'required',
	//     ]);

	//     if ($validator->fails()) {

	//         return response()->json([
	//             'success' => false,
	//             'message' => 'Semua Kolom Wajib Diisi!',
	//             'data'   => $validator->errors()
	//         ],401);

	//     } else {

	//         $post = Post::whereId($id)->update([
	//             'title'     => $request->input('title'),
	//             'content'   => $request->input('content'),
	//         ]);

	//         if ($post) {
	//             return response()->json([
	//                 'success' => true,
	//                 'message' => 'Post Berhasil Diupdate!',
	//                 'data' => $post
	//             ], 201);
	//         } else {
	//             return response()->json([
	//                 'success' => false,
	//                 'message' => 'Post Gagal Diupdate!',
	//             ], 400);
	//         }

	//     }
	// }

	// public function destroy($id)
	// {
	//     $post = Post::whereId($id)->first();
	// 		$post->delete();

	//     if ($post) {
	//         return response()->json([
	//             'success' => true,
	//             'message' => 'Post Berhasil Dihapus!',
	//         ], 200);
	//     }
	// }









}

