1. Folder Project ada di MyApp
2. Database menggunakan db_lumen_api.sql